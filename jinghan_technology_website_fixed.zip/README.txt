# 株式会社境涵テクノロジー - Free Website

このフォルダには GitHub Pages で無料公開できる静的サイトが入っています。

## 変更する場所
`index.html` の以下を変更してください。

1. `YOUR_EMAIL@example.com` → 実際の会社メール
2. 必要なら会社説明、サービス、取扱分野を変更

## GitHub Pages 公開方法
1. GitHubで新しいRepositoryを作成
2. `index.html` と `style.css` をアップロード
3. Repository → Settings → Pages
4. Sourceを「Deploy from a branch」
5. Branchを `main` / `root` にしてSave
6. 数分後に `https://あなたのユーザー名.github.io/リポジトリ名/` で公開
