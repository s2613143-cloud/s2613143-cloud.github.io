import '../globals.css';
export const metadata = { title: '境涵科技 | Jinghan Technology', robots: { index: false } };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="ja"><body>{children}</body></html>);
}
