// Sends visitors to the language that matches their browser (falls back to Japanese).
export default function Page() {
  const js = "var l=(navigator.language||'ja').toLowerCase();location.replace(l.indexOf('zh')==0?'/zh/':l.indexOf('en')==0?'/en/':'/ja/')";
  return (
    <main className="p-10 text-center">
      <script dangerouslySetInnerHTML={{ __html: js }} />
      <p><a href="/ja/">日本語</a>　<a href="/zh/">中文</a>　<a href="/en/">English</a></p>
    </main>
  );
}
