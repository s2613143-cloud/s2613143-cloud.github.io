import Link from 'next/link';
import type { ReactNode } from 'react';
import { c, locales, labels, type Locale, type S } from '@/lib/content';
import { EMAIL } from '@/lib/site';

const Sec = ({ id, alt, children }: { id?: string; alt?: boolean; children: ReactNode }) => (
  <section id={id} className={`py-14 md:py-20 ${alt ? 'bg-paper' : ''}`}>
    <div className="mx-auto max-w-5xl px-5">{children}</div>
  </section>
);
const H2 = ({ children }: { children: ReactNode }) => (
  <h2 className="mb-5 text-2xl font-bold leading-snug text-navy md:text-3xl">{children}</h2>
);
const Card = ({ title, children }: { title: ReactNode; children: ReactNode }) => (
  <div className="border border-line border-t-[3px] border-t-navy bg-white p-5">
    <h3 className="mb-2 text-base font-bold leading-snug text-navy">{title}</h3>
    {children}
  </div>
);
const Ul = ({ items, l }: { items: S[]; l: Locale }) => (
  <ul className="my-4 space-y-1">
    {items.map((i, k) => (
      <li key={k} className="relative pl-5 before:absolute before:left-0 before:top-[0.85em] before:h-0.5 before:w-2.5 before:bg-gold">{i[l]}</li>
    ))}
  </ul>
);
const btn = 'inline-block px-7 py-3 font-bold transition-opacity hover:opacity-90 ';
const grid = 'grid gap-4 sm:grid-cols-2 lg:grid-cols-3';

export default function Page({ params }: { params: { lang: Locale } }) {
  const l = params.lang;
  const nav = [['Home', '#home'], ['About', '#about'], ['Services', '#services'], ['Sourcing', '#sourcing'], ['Contact', '#contact']];
  return (
    <>
      <header className="sticky top-0 z-10 bg-navy text-white">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-x-6 px-5">
          <a href="#home" className="py-3 font-bold tracking-wide">
            境涵科技 <span className="ml-1 text-xs font-normal text-gold">Jinghan Technology</span>
          </a>
          <nav className="order-last flex w-full gap-6 overflow-x-auto pb-2 text-sm md:order-none md:w-auto md:pb-0">
            {nav.map(([n, h]) => (<a key={h} href={h} className="whitespace-nowrap hover:text-gold">{n}</a>))}
          </nav>
          <div className="flex overflow-hidden rounded border border-white/30 text-sm">
            {locales.map((x) => (
              <Link key={x} href={`/${x}/`} hrefLang={x} aria-current={x === l ? 'true' : undefined}
                className={`px-3 py-1 ${x === l ? 'bg-gold font-bold text-navy' : 'hover:bg-white/10'}`}>{labels[x]}</Link>
            ))}
          </div>
        </div>
      </header>

      <main id="home">
        <div className="border-b-[3px] border-gold bg-navy py-20 text-white md:py-28">
          <div className="mx-auto max-w-5xl px-5">
            <h1 className="whitespace-pre-line text-3xl font-bold leading-tight md:text-5xl">{c.hero.title[l]}</h1>
            <p className="mt-6 max-w-xl text-[#cdd7e5]">{c.hero.sub[l]}</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href="#contact" className={btn + 'bg-gold text-navy'}>{c.hero.cta1[l]}</a>
              <a href="#services" className={btn + 'border border-gold text-white'}>{c.hero.cta2[l]}</a>
            </div>
          </div>
        </div>

        <Sec>
          <H2>{c.what.title[l]}</H2>
          <p className="max-w-3xl text-mute">{c.what.intro[l]}</p>
          <Ul items={c.what.points} l={l} />
          <p className="max-w-3xl text-mute">{c.what.outro[l]}</p>
        </Sec>

        <Sec alt>
          <H2>{c.process.title[l]}</H2>
          <ol className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            {c.process.steps.map((s, i) => (
              <li key={i} className="border border-line border-t-[3px] border-t-navy bg-white p-5">
                <div className="text-sm font-bold text-gold">{String(i + 1).padStart(2, '0')}</div>
                <h3 className="mb-2 font-bold text-navy">{s.t[l]}</h3>
                <p className="text-sm text-mute">{s.d[l]}</p>
              </li>
            ))}
          </ol>
        </Sec>

        <Sec id="services">
          <H2>{c.services.title[l]}</H2>
          <div className={grid}>
            {c.services.items.map((s, i) => (
              <Card key={i} title={s.t[l]}>
                <p className="text-sm text-mute">{s.d[l]}</p>
                {'k' in s && s.k && <p className="mt-3 text-sm font-semibold text-navy">{s.k[l]}</p>}
              </Card>
            ))}
          </div>
        </Sec>

        <Sec id="sourcing" alt>
          <H2>{c.sourcing.title[l]}</H2>
          <div className={grid}>
            {c.sourcing.items.map((s, i) => (<Card key={i} title={s.t[l]}><p className="text-sm text-mute">{s.d[l]}</p></Card>))}
          </div>
        </Sec>

        <Sec>
          <H2>{c.why.title[l]}</H2>
          <div className={grid}>
            {c.why.items.map((s, i) => (<Card key={i} title={s.t[l]}><p className="text-sm text-mute">{s.d[l]}</p></Card>))}
          </div>
        </Sec>

        <Sec alt>
          <H2>{c.map.title[l]}</H2>
          <p className="max-w-3xl text-mute">{c.map.text[l]}</p>
          <div className="mt-6 rounded bg-navy p-3">
            <svg viewBox="0 0 720 260" role="img" aria-label="China - Japan - Global" className="block h-auto w-full">
              <defs>
                <marker id="ar" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L10 5L0 10z" fill="#b8975a" /></marker>
              </defs>
              <g fill="none" stroke="#b8975a" strokeWidth="1.6" markerEnd="url(#ar)">
                <path d="M190 105 C300 40 430 40 520 80" />
                <path d="M520 120 C430 160 300 160 195 125" strokeDasharray="5 5" />
                <path d="M170 150 C230 215 400 235 540 215" />
              </g>
              <g fontFamily="sans-serif" textAnchor="middle">
                <circle cx="140" cy="115" r="52" fill="#13305a" stroke="#b8975a" /><text x="140" y="121" fill="#fff" fontSize="18">China</text>
                <circle cx="570" cy="100" r="46" fill="#13305a" stroke="#fff" strokeOpacity=".4" /><text x="570" y="106" fill="#fff" fontSize="18">Japan</text>
                <circle cx="590" cy="215" r="34" fill="#13305a" stroke="#fff" strokeOpacity=".4" /><text x="590" y="220" fill="#fff" fontSize="14">Global</text>
                <text x="360" y="52" fill="#b8975a" fontSize="12">China → Japan</text>
                <text x="360" y="178" fill="#b8975a" fontSize="12">Japan → China</text>
                <text x="360" y="232" fill="#b8975a" fontSize="12">China → Global</text>
              </g>
            </svg>
          </div>
        </Sec>

        <Sec>
          <div className="grid gap-5 md:grid-cols-2">
            <div className="border border-line p-7">
              <h3 className="mb-3 text-lg font-bold text-navy">{c.jp.title[l]}</h3>
              <p>{c.jp.intro[l]}</p>
              <Ul items={c.jp.points} l={l} />
              <p className="mb-5">{c.jp.outro[l]}</p>
              <a href="#contact" className={btn + 'bg-gold text-navy'}>{c.jp.cta[l]}</a>
            </div>
            <div className="bg-navy p-7 text-[#dbe3ee]">
              <h3 className="mb-3 text-lg font-bold text-white">{c.cn.title[l]}</h3>
              <p>{c.cn.text[l]}</p>
              <p className="my-4 font-bold text-gold">{c.cn.em[l]}</p>
              <a href="#contact" className={btn + 'border border-gold text-white'}>{c.cn.cta[l]}</a>
            </div>
          </div>
        </Sec>

        <Sec id="contact" alt>
          <H2>{c.contact.title[l]}</H2>
          <p className="mb-6 max-w-3xl text-mute">{c.contact.text[l]}</p>
          <a href={`mailto:${EMAIL}`} className={btn + 'bg-gold text-navy'}>{EMAIL}</a>
        </Sec>

        <Sec id="about">
          <H2>{c.about.title[l]}</H2>
          <p className="max-w-3xl text-mute">{c.about.text[l]}</p>
          <div className="mt-8 border border-line border-t-[3px] border-t-gold">
            <h3 className="px-6 pt-5 text-lg font-bold text-navy">{c.profile.title[l]}</h3>
            <dl className="mt-3">
              {c.profile.rows.map((r, i) => (
                <div key={i} className="grid gap-1 border-t border-line px-6 py-3 text-sm md:grid-cols-[200px_1fr] md:gap-4">
                  <dt className="font-bold text-navy">{r.k[l]}</dt>
                  <dd>{r.v[l].split('\n').map((line, j) => (<div key={j}>{line}</div>))}</dd>
                </div>
              ))}
            </dl>
          </div>
        </Sec>
      </main>

      <footer className="bg-navy py-10 text-sm text-[#aebbd0]">
        <div className="mx-auto max-w-5xl space-y-3 px-5">
          <p><b className="text-white">{c.footer.company[l]}</b><br />{c.footer.en}<br />{c.footer.tag}</p>
          <p className="flex flex-wrap gap-4">{nav.map(([n, h]) => (<a key={h} href={h} className="hover:text-gold">{n}</a>))}</p>
          <p className="flex flex-wrap gap-4">{locales.map((x) => (<Link key={x} href={`/${x}/`} className="hover:text-gold">{labels[x]}</Link>))}</p>
          <p>© 2026 {c.footer.en}</p>
        </div>
      </footer>
    </>
  );
}
