import type { Metadata } from 'next';
import '../globals.css';
import { locales, c, type Locale } from '@/lib/content';
import { SITE_URL } from '@/lib/site';

export const dynamicParams = false;
export function generateStaticParams() { return locales.map((lang) => ({ lang })); }

export function generateMetadata({ params }: { params: { lang: Locale } }): Metadata {
  const l = params.lang;
  return {
    metadataBase: new URL(SITE_URL),
    title: c.meta.title[l],
    description: c.meta.desc[l],
    keywords: c.meta.keywords[l],
    alternates: {
      canonical: `/${l}/`,
      languages: { ja: '/ja/', 'zh-CN': '/zh/', en: '/en/', 'x-default': '/ja/' },
    },
    openGraph: { title: c.meta.title[l], description: c.meta.desc[l], type: 'website', url: `/${l}/` },
  };
}

export default function RootLayout({ children, params }: { children: React.ReactNode; params: { lang: Locale } }) {
  return (<html lang={params.lang === 'zh' ? 'zh-CN' : params.lang}><body>{children}</body></html>);
}
