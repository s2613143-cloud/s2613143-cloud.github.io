import type { MetadataRoute } from 'next';
import { locales } from '@/lib/content';
import { SITE_URL } from '@/lib/site';
export const dynamic = 'force-static';
export default function sitemap(): MetadataRoute.Sitemap {
  return locales.map((l) => ({ url: `${SITE_URL}/${l}/`, lastModified: new Date() }));
}
