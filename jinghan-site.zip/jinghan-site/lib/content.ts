export const locales = ['ja', 'zh', 'en'] as const;
export type Locale = (typeof locales)[number];
export type S = Record<Locale, string>;
export const labels: Record<Locale, string> = { ja: '日本語', zh: '中文', en: 'English' };
const t = (ja: string, zh: string, en: string): S => ({ ja, zh, en });

export const c = {
  meta: {
    title: t(
      '境涵科技 | 中国仕入れ・工場選定・調達サポート｜Jinghan Technology',
      '境涵科技 | 中国采购·工厂筛选·供应链整合｜Jinghan Technology',
      'Jinghan Technology | China Sourcing, Factory Selection & Procurement'),
    desc: t(
      '中国メーカーの選定から調達・価格交渉・輸出まで、企業間取引を一貫してサポート。中国仕入れ・中国工場選定・中国サプライヤー開拓なら境涵科技へ。',
      '从中国供应商寻找、工厂筛选、价格谈判到出口，境涵科技为海外企业提供一站式中国采购与供应链支持。',
      'Jinghan Technology supports overseas buyers with China sourcing: supplier search, factory selection, price negotiation and export, from inquiry to purchase.'),
    keywords: {
      ja: '中国仕入れ,中国メーカー,中国工場,中国調達,中国輸入,中国サプライヤー,中国製品調達,海外調達,中国OEM,中国工場選定',
      zh: '中国采购,中国供应商,中国工厂,中国制造,中国供应链,中国进口,中国工厂筛选',
      en: 'China sourcing,China supplier,China manufacturer,China procurement,China factory sourcing,China supply chain,China import,China manufacturing',
    } as S,
  },
  brandSub: 'Jinghan Technology',
  hero: {
    title: t('中国のサプライチェーンを、\n世界のビジネスへ。', '连接中国供应链，\n让采购更简单。', 'Connecting Global Businesses\nwith China’s Supply Chain.'),
    sub: t(
      '中国メーカーの選定から調達・価格交渉・輸出まで、企業間取引を一貫してサポートします。',
      '从中国工厂筛选、采购、价格谈判到出口，全程支持企业间交易。',
      'We support B2B transactions end to end, from selecting Chinese manufacturers to procurement, price negotiation and export.'),
    cta1: t('調達のご相談', '采购需求咨询', 'Discuss your sourcing'),
    cta2: t('中国サプライヤーを探す', '寻找中国供应商', 'Find Chinese suppliers'),
  },
  what: {
    title: t('中国のサプライチェーンは、工場探しから。', '中国供应链，从寻找工厂开始。', 'China’s supply chain starts with finding the right factory.'),
    intro: t(
      '中国には巨大な製造業のサプライチェーンがありますが、海外企業にとって本当に難しいのは「商品を見つけること」ではなく、次のような点です。',
      '中国拥有庞大的制造业供应链，但对海外企业而言，真正困难的往往不是“找到产品”，而是：',
      'China has a vast manufacturing supply chain. For overseas companies, the hard part is rarely finding a product. It is:'),
    points: [
      t('本当に生産能力のある工場を見つける', '找到真正具备生产能力的工厂', 'Finding factories that truly have production capacity'),
      t('工場が信頼できるかを見極める', '判断工厂是否可靠', 'Judging whether a factory is reliable'),
      t('複数サプライヤーの価格を比較する', '比较不同供应商的价格', 'Comparing prices across suppliers'),
      t('製品仕様・生産条件を確認する', '确认产品规格与生产条件', 'Confirming specifications and production conditions'),
      t('中国語でのやり取りと価格交渉', '进行中文沟通和价格谈判', 'Communicating and negotiating in Chinese'),
      t('調達コストの管理、輸出・越境取引の調整', '控制采购成本，协调出口及跨境交易', 'Controlling procurement cost and coordinating export'),
    ],
    outro: t(
      '境涵科技は中国の製造側と海外の調達側をつなぎ、お客様の要件に合うサプライヤー・工場を探し、見積から調達までの流れを推進します。',
      '境涵科技连接中国制造端与海外采购端，根据客户实际需求寻找合适的中国供应商与工厂，并推进从询价到采购的整个流程。',
      'Jinghan Technology links Chinese manufacturers with overseas buyers. We find suppliers and factories that fit your requirements and carry the process from inquiry through to purchase.'),
  },
  process: {
    title: t('ご要望から調達まで', '从需求到采购', 'From requirement to purchase'),
    steps: [
      { t: t('要件確認', '需求确认', 'Requirements'), d: t('製品・仕様・数量・予算・納期条件を確認します。', '了解产品、规格、数量、预算及交付条件。', 'We confirm the product, specifications, quantity, budget and delivery terms.') },
      { t: t('サプライヤー選定', '供应商筛选', 'Supplier selection'), d: t('条件に合うメーカー・サプライヤーを探します。', '在中国供应链中寻找符合条件的制造商及供应商。', 'We find manufacturers and suppliers that meet your requirements.') },
      { t: t('見積・比較', '询价与比较', 'Quotes & comparison'), d: t('価格、MOQ、生産能力、納期などを比較します。', '从价格、MOQ、生产能力、交期等方面比较报价。', 'We compare price, MOQ, production capacity and lead time.') },
      { t: t('工場との交渉', '工厂沟通与谈判', 'Factory negotiation'), d: t('中国工場と直接やり取りし、仕様・価格・条件を確認します。', '直接与工厂沟通，确认规格、价格、生产条件及交付方式。', 'We talk directly with factories to confirm specs, price, production and delivery terms.') },
      { t: t('調達・輸出', '采购与出口', 'Procurement & export'), d: t('合意した取引条件に沿って調達・生産・輸出を進めます。', '按双方确定的条件推进采购、生产及出口流程。', 'We move purchasing, production and export forward under the agreed terms.') },
    ],
  },
  services: {
    title: t('事業内容', '核心服务', 'Services'),
    items: [
      { t: t('中国サプライヤー・工場探し', '中国供应商 / 工厂寻找', 'Supplier & Factory Search'),
        d: t('工場選定、地方メーカーの発掘、サプライヤー比較、仕様・MOQ・納期の確認。', '工厂筛选、地方制造商寻找、供应商比较、规格与 MOQ / 交期确认。', 'Factory screening, local manufacturer search, supplier comparison, and confirmation of specifications, MOQ and lead time.'),
        k: t('供給元を探すだけでなく、実際の生産能力と調達条件を重視します。', '不仅寻找供应商，更重视实际生产能力与采购条件。', 'We look beyond the supplier list to real production capacity and purchasing terms.') },
      { t: t('工場選定とコスト最適化', '工厂选择与成本优化', 'Factory Selection & Cost Optimization'),
        d: t('中国は地域ごとに産業集積と強みが異なります。製品と条件に応じて適した地域の工場を探し、不要な中間コストを抑えます。', '中国不同地区拥有不同的产业集群与制造优势。我们按产品和条件选择合适地区的工厂，尽量减少不必要的中间成本。', 'Each region of China has its own industrial clusters. We find suitable factories by product and terms, and cut unnecessary intermediary costs.'),
        k: t('最安値ではなく、適した工場を選びます。', '选择合适的工厂，而不是单纯寻找最低价格。', 'The right factory, not just the lowest price.') },
      { t: t('価格交渉', '价格谈判', 'Price Negotiation'),
        d: t('中国語での交渉を代行：見積、MOQ、支払条件、生産期間、梱包、納品条件。', '协助以中文沟通与谈判：报价、MOQ、付款条件、生产周期、包装、交货条件。', 'We handle Chinese-language negotiation: quotations, MOQ, payment terms, lead time, packaging and delivery terms.') },
      { t: t('中国製品調達', '中国商品采购', 'China Sourcing'),
        d: t('工業製品、機械、金属製品からペット用品まで。単品調達、複数カテゴリ、長期サプライヤー開拓に対応。', '从工业产品、机械设备、金属制品到宠物用品。支持单一产品、多品类采购及长期供应商开发。', 'From industrial products, machinery and metal products to pet products. Single items, multiple categories or long-term supplier development.') },
      { t: t('中国製造業へのアクセス', '海外企业进入中国供应链', 'Access to Chinese Manufacturing'),
        d: t('中国での調達ルートを広げたい海外企業に、メーカーやサプライチェーンへの接点を提供します。', '帮助希望扩大中国采购渠道的海外企业接触中国制造商及供应链资源。', 'We connect overseas companies expanding their China sourcing with manufacturers and supply chain resources.') },
    ],
  },
  sourcing: {
    title: t('取扱カテゴリ', '产品类别', 'What We Source'),
    items: [
      { t: t('工業製品', '工业产品', 'Industrial Products'), d: t('機械設備、金属製品、部品、工業材料など。', '机械设备、金属制品、零部件、工业材料等。', 'Machinery, metal products, components, industrial materials and more.') },
      { t: t('自動車・機械関連', '汽车及机械相关产品', 'Automotive & Machinery'), d: t('自動車部品、機械部品、設備など。', '汽车零部件、机械零件、设备及相关产品。', 'Automotive parts, machine parts, equipment and related products.') },
      { t: t('金属製品', '金属制品', 'Metal Products'), d: t('金属加工品、構造部材、部品など。', '金属加工件、结构件、零部件等。', 'Metal processed parts, structural parts and components.') },
      { t: t('ペット用品', '宠物用品', 'Pet Products'), d: t('ペット用品、関連機器・製品。', '宠物用品、宠物设备及相关产品。', 'Pet supplies, pet equipment and related products.') },
      { t: t('その他の調達', '其他采购需求', 'Custom Sourcing'), d: t('上記以外の中国製品もお気軽にご相談ください。', '如果您在寻找其他中国制造产品，也欢迎联系我们。', 'Looking for another product made in China? Get in touch.') },
    ],
  },
  why: {
    title: t('境涵科技が選ばれる理由', '为什么选择境涵', 'Why Jinghan'),
    items: [
      { t: t('中国サプライチェーン', '中国供应链资源', 'China supply chain access'), d: t('製造業のサプライチェーンに入り込み、適した生産企業を探します。', '深入中国制造业供应链，寻找合适的生产企业。', 'We work inside China’s manufacturing supply chain to find suitable producers.') },
      { t: t('中国語で直接交渉', '中文沟通', 'Direct Chinese communication'), d: t('サプライヤーと直接やり取りし、言語・情報の壁を減らします。', '直接与供应商沟通，减少语言和信息差。', 'We speak with suppliers directly, reducing language and information gaps.') },
      { t: t('工場の選定', '工厂筛选', 'Factory screening'), d: t('単なるリスト提供ではなく、実際の要件で工場を絞り込みます。', '按实际采购需求筛选，而不是只提供供应商名单。', 'We screen factories against your real requirements, not just hand over a list.') },
      { t: t('コスト意識', '成本意识', 'Cost awareness'), d: t('サプライヤー・地域・条件の多面でコストを最適化します。', '从供应商、地区、采购条件多角度优化成本。', 'We optimize cost across suppliers, regions and purchasing terms.') },
      { t: t('取引の実行まで', '面向实际交易', 'Built for real transactions'), d: t('レポートで終わらず、実際の調達・企業間取引を中心に動きます。', '以实际采购和企业间交易为核心，而不是只提供咨询报告。', 'We focus on actual purchasing and B2B trade, not just advisory reports.') },
    ],
  },
  map: {
    title: t('中国と世界の企業をつなぐ', '连接跨境企业', 'Connecting Businesses Across Borders'),
    text: t(
      '境涵科技は中国の製造企業と海外の調達企業をつなぎ、越境調達とサプライチェーンを支援します。',
      '境涵科技连接中国制造企业与海外采购企业，提供跨境采购与供应链支持。',
      'Jinghan Technology connects Chinese manufacturers with overseas buyers and supports cross-border sourcing and supply chains.'),
  },
  jp: {
    title: t('中国から仕入れたい企業様へ', '致希望从中国采购的企业', 'For companies that want to buy from China'),
    intro: t('商品・部品・機械・金属製品などを中国から調達したいが、', '想从中国采购商品、零部件、机械、金属制品，却面临：', 'You want to source products, parts, machinery or metal goods from China, but:'),
    points: [
      t('どの工場に依頼すればいいかわからない', '不知道该找哪家工厂', 'You do not know which factory to approach'),
      t('中国語でのやり取りが難しい', '中文沟通有困难', 'Chinese-language communication is difficult'),
      t('複数の工場から見積を取りたい', '想向多家工厂询价', 'You want quotes from several factories'),
      t('もっとコストを抑えたい', '希望进一步降低成本', 'You want to bring costs down'),
    ],
    outro: t('そんな企業様に、中国側のサプライヤー・メーカー探しから交渉までをサポートします。', '我们从寻找中国供应商、制造商，到谈判全程支持。', 'We support you from finding suppliers and manufacturers in China through to negotiation.'),
    cta: t('調達について相談する', '咨询采购需求', 'Discuss your sourcing'),
  },
  cn: {
    title: t('中国メーカー・サプライヤーの皆様へ', '致中国制造商与供应商', 'For Chinese manufacturers and suppliers'),
    text: t(
      '日本・海外市場の開拓をご希望の方は、ぜひご連絡ください。海外企業の実際の調達ニーズに基づき、条件に合う中国サプライヤーをご紹介します。',
      '如果您希望拓展日本及海外市场，欢迎联系我们。我们根据海外企业的实际采购需求匹配符合条件的中国供应商。',
      'If you want to expand into Japan and overseas markets, contact us. We match suppliers to the real purchasing needs of overseas companies.'),
    em: t('製品を掲載するだけでなく、実際の調達ニーズに基づくサプライヤーマッチングを重視します。', '重点不是单纯发布产品，而是基于实际采购需求进行供应商匹配。', 'We do not just list products. We match suppliers to actual sourcing needs.'),
    cta: t('お問い合わせ', '联系我们', 'Contact us'),
  },
  contact: {
    title: t('お問い合わせ', '联系我们', 'Contact Us'),
    text: t(
      '中国サプライヤーの開拓、製品調達、工場選定などについて、お気軽にお問い合わせください。製品名・仕様・数量をお知らせいただくとスムーズです。',
      '关于中国供应商开发、产品采购、工厂选择等，欢迎随时联系。若能告知产品名称、规格和数量，沟通会更顺畅。',
      'Tell us what you are looking for. We will review your requirements and explore suitable sourcing options in China. Product name, specifications and quantity help us respond faster.'),
  },
  about: {
    title: t('境涵科技について', '关于境涵科技', 'About Jinghan Technology'),
    text: t(
      '上海境涵科技有限公司は、越境調達と中国サプライチェーンの統合に特化した企業です。海外企業と中国の製造業をつなぎ、越境調達に伴う情報格差・コミュニケーションコスト・サプライチェーンの参入障壁を減らします。サプライヤー探し、工場選定から、見積、交渉、調達まで、企業の実際のニーズを中心に、適した中国サプライチェーンのソリューションをご提案します。',
      '上海境涵科技有限公司是一家专注于跨境采购与中国供应链整合的企业。我们通过连接海外企业与中国制造业，降低跨境采购中的信息差、沟通成本与供应链门槛。从供应商寻找、工厂筛选，到询价、沟通和采购，我们以企业实际需求为中心，寻找合适的中国供应链解决方案。',
      'Shanghai Jinghan Technology Co., Ltd. focuses on cross-border procurement and China supply chain integration. By connecting overseas companies with Chinese manufacturing, we reduce the information gaps, communication costs and supply chain barriers in cross-border sourcing. From supplier search and factory selection to quotations, communication and purchasing, we work from each company’s real needs to find a suitable China supply chain solution.'),
  },
  profile: {
    title: t('会社概要', '公司概要', 'Company Profile'),
    rows: [
      { k: t('会社名', '公司名称', 'Company Name'), v: t('上海境涵科技有限公司\nShanghai Jinghan Technology Co., Ltd.', '上海境涵科技有限公司\nShanghai Jinghan Technology Co., Ltd.', 'Shanghai Jinghan Technology Co., Ltd.') },
      { k: t('ブランド名', '品牌名称', 'Brand'), v: t('境涵科技 | Jinghan Technology', '境涵科技 | Jinghan Technology', 'Jinghan Technology') },
      { k: t('所在地', '所在地', 'Location'), v: t('中国・上海', '中国・上海', 'Shanghai, China') },
      { k: t('事業内容', '业务内容', 'Business'),
        v: t('中国メーカー・サプライヤーの開拓および選定、製品調達、工場選定、見積取得、価格交渉、サプライチェーン開拓、越境取引のサポートなど。',
             '中国供应商及制造商的开发与筛选\n中国工厂寻找\n企业采购支持\n产品询价及价格谈判\n中国商品采购\n跨境贸易支持\n中国供应链整合\n海外企业与中国制造商的业务对接',
             'China sourcing, supplier development, factory selection, procurement support, price negotiation and cross-border trade support.') },
      { k: t('主な事業エリア', '主要业务地区', 'Markets'), v: t('中国・日本・海外市場', '中国・日本・海外市场', 'China, Japan and global markets.') },
      { k: t('主な取引対象', '主要服务对象', 'Clients'),
        v: t('日本および海外の企業、購買担当者、輸入業者、商社、販売代理店など。', '日本及海外的企业、采购商、进口商、贸易公司、经销商等', 'Companies, purchasing organizations, importers, trading companies and distributors.') },
      { k: t('取扱分野', '主要采购领域', 'Product Categories'),
        v: t('産業製品、機械設備、金属製品、部品、ペット用品など、企業からの具体的な調達ニーズに応じて幅広く対応。', '工业产品、机械设备、金属制品、零部件、宠物用品及其他企业采购需求', 'Industrial products, machinery, metal products, components, pet products and other products based on specific sourcing requirements.') },
    ],
  },
  footer: { company: t('上海境涵科技有限公司', '上海境涵科技有限公司', 'Shanghai Jinghan Technology Co., Ltd.'), en: 'Shanghai Jinghan Technology Co., Ltd.', tag: 'China Supply Chain | Sourcing | Procurement' },
};
