// Set NEXT_PUBLIC_SITE_URL in your host's environment variables (e.g. https://www.your-domain.com)
export const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://example.com';
// Replace with the real contact address
export const EMAIL = 'contact@XXXX.com';
